/* eslint-disable */
import '@/assets/css/com.less';
import './contact.less';
import  '@/assets/js/750rem';
import {throttle} from '@/assets/js/tools/utils';
console.log(throttle);

console.log('22222');
